/*
 *Program to find time taken to execute getpid() system call using time stamp counter.
 */
#include<stdio.h>
#include<unistd.h>
#include<sys/time.h>
unsigned long long rdtsc()
{
	unsigned long long dst;
	__asm__ __volatile__ ("rdtsc":"=a" (dst));
}

int main()
{
	int i,nano;
	unsigned long long int start,end;
	start=rdtsc();
	for(int i=0;i<1000;i++)
		getpid();
	end=rdtsc();
	nano = (end-start)/2.1;
	printf("Time taken to execute getpid system call is %d nanoseconds\n",nano);
}
