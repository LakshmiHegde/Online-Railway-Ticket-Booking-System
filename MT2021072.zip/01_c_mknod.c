/*
 *Creating named pipe, fifo file, using mknod system call
 */
#include<sys/types.h>
#include<stdio.h>
#include<fcntl.h>
#include<sys/stat.h>
void main()
{
	int fd=mknod("myfifofile_mknod",S_IFIFO|0777,0);
	if(fd == 0)
		printf("File created succesfully\n");
	else
		printf("Error\n");
}
