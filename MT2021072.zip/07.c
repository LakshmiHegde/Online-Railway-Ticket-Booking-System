/*
 *Program to mimic , "cp" linux command, using read, write system calls.
 *Provide file name to copy, as command line arguments
 *
 */
#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<stdlib.h>
void main(int argc, char *argv[])
{
	if(argc <3)
	{
		printf("Provide filenames as command line arguments\n");
		exit(0);
	}
	int fd1=open(argv[1],O_RDONLY);
	int fd2=open(argv[2],O_TRUNC|O_WRONLY|O_CREAT,0777);
	char ch;

	printf("%d : %s\n",fd1,argv[1]);
	printf("%d : %s\n",fd2,argv[2]);
	while(read(fd1,&ch,1) != 0)
	{
		write(fd2,&ch,1);
	}
	//write(fd2,&ch,1);
	
	printf("Content of %s copied to %s successfully\n",argv[1],argv[2]);
}
