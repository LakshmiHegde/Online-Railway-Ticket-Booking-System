/*
 *5. execvp - Same as execp, just that, arguments can be passed in array.
 */
#include<stdio.h>
#include<unistd.h>
void main()
{
	char *args[]={"ls","-Rl",NULL};
	int x=execvp("ls",args);
	if(x == -1)
		perror("");
}
