/*
 *
 *2. execlp - Executable program which is passed in execlp, is searched in the path specified in PATH env variable. You need not use entire path, if path is already in PATH, just mention the file name.
 */
#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
void main()
{
	int status=execlp("ls","ls","-Rl",NULL);
	if(status == -1)
		perror("");
}
