/*
 *Program to demeonstrate fork() system call, and printing process ID of parent and child process
 */
#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>
void main()
{
	if(!fork())
		printf("I am child process, My process ID is %d\n",getpid());
	else
	{
		printf("I am parent process, My process ID is %d\n",getpid());
		wait(NULL);
	}
}
