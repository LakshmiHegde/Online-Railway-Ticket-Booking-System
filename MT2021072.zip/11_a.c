/*
 *Program to duplicate file descriptor, and append the file, with both original and copied descriptor ,using dup() system call
 *dup(), uses the least file descriptor, currently available, as the copied value .
 */
#include<string.h>
#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
void main()
{
	char fname[30];
	printf("Enter file name \n");
	scanf("%s",fname);

	int x=open(fname,O_RDWR);
	int copy=dup(x);
	printf("Original Descriptor  = %d\nCopied descriptor = %d\n",x,copy);

	
	write(x,"This is using original descriptor\n",strlen("This is using original descriptor\n"));
	write(copy,"This is using copied descriptor\n",strlen("This is using copied descriptor\n"));
}


