/*
 *Program to demonstrate use of select system call.
 *Select system call enables monitoring of file descriptors, either  in read or write operation. If any of the file descriptors that are under monitoring, changes its state, we can get to know.
 *We monitor the standard input, and if any input is available within the time specified, accordingly we print relevant message.
 */
#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/types.h>
#include<sys/time.h>
#include<sys/stat.h>
void main()
{
	fd_set set;
	FD_SET(0,&set);
	struct timeval t;
	t.tv_sec=10;
	t.tv_usec=0;
	printf("Enter something\n");
	int ret=select(1,&set,NULL,NULL,&t);
	
	if(ret == 0)
		printf("No data is  available in 10 seconds\n");
	else if(ret == -1)
		perror("");
	else 
		printf("Data is available in 10 seconds\n");


			
}


