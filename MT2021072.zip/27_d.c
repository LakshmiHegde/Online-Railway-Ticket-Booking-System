/*
 *4. execv - Arguments that are needed for executable file can be passed as an array
 */
#include<stdio.h>
#include<unistd.h>
void main()
{
	char *args[]={"ls","-Rl",NULL};
	int x=execv("/bin/ls",args);
	if(x == -1)
		perror("");
}
