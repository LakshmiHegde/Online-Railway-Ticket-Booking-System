/*
 *Program to append content to file,  from parent and child process
 */
#include<sys/types.h>
#include<fcntl.h>
#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>
#include<string.h>
void main()
{
	int fd=open("forkfile",O_CREAT|O_RDWR,0777);
	if(!fork())
	{
		char buffer[100] ="Writing from child process\n";
		write(fd,&buffer,strlen(buffer));
		printf("Child written content succesfully to forkfile\n");
	}
	else
	{
		char buffer[100] ="Writing from parent process\n";
		write(fd,&buffer,strlen(buffer));
		printf("Parent written content succesfully to forkfile\n");
		wait(NULL);
	}
	close(fd);
}
