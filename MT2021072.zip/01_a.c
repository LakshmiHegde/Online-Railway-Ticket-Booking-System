/*
 * Program to create symbollic link, using symlink system call.
 *
 */
#include<unistd.h>
#include<stdio.h>
#include<fcntl.h>
void main()
{
	const char* src="/home/lakshmihegde/Desktop/Exercise/file.txt";
	const char *target = "/home/lakshmihegde/Desktop/file_shortcut.txt";
	int status=symlink(src,target);
	if(status  == 0)
		printf("Soft link created successfully\n");
	else
		printf("Soft link creation failed\n");
}
