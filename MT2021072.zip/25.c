/*
 *Program to make parent process, wait to collect, status of particular child process.
 *Using wait(), if any of the children exits, parent will collect it off.
 *If you want to wait it for particular process, use waitpid, by passing child's process ID, which now makes parent to wait for that particular process.
 */
#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>
void main()
{
	int c1=fork();
	if(c1 !=0 )
	{
		int c2=fork();
		if(c2!=0)
		{
			int c3=fork();
			if(c3!=0)
			{
				//here I have access for all child PID values, c1,c2,c3
				//I will receive for wait status of c2
			//	printf("Waiting for second child to complete\n");
				int r=waitpid(c1,0,0);
				printf("Collected status of process %d and parent exited\n",r);
			}
			else
			{
				printf("Third child %d\n",getpid());
			}
		
		}
		else
		{
			printf("Second child %d\n",getpid());
			//sleep(10);
		}
	}
	else
	{
		printf("First child %d\n",getpid());
	}
}

