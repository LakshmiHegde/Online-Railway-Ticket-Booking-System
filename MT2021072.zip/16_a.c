/*
 *Program to demonstrate mandatory write locking. You should aacquire lock on entire file, so that anyone else accessing this file at same time, should not be allowed to do so.
 */
#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/types.h>

void main()
{
	struct flock f;
	f.l_type = F_WRLCK;
	f.l_whence = SEEK_SET;
	f.l_start=0;
	f.l_len=0;
	f.l_pid=getpid();
	int fd=open("file",O_RDWR);
	printf("WRITE LOCK \n");
	printf("Entry section\n");

	int x=fcntl(fd,F_SETLKW,&f);//set lock
	
	printf("Inside critical section");
	printf("\nPress 0 to exit\n");
	getchar();
	
	printf("Unlocked\n");
	f.l_type=F_UNLCK;
	fcntl(fd,F_SETLK,&f);//unlock
	
	printf("Exit\n");
}
	
