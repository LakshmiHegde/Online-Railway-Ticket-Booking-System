/*
 *Program to demonstrate execv system call. Execute any executable program, by passing it to execv .
 */
#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<fcntl.h>
void main(int argc,char *argv[])
{
	if(argc<2)
	{
		printf("Provide executable file, as command line argument\n");
		exit(0);
	}
	char *const a[]={argv[1],"Lakshmi",NULL};
	int x=execv(argv[1],a);
	if(x == -1)
		perror("");
}
