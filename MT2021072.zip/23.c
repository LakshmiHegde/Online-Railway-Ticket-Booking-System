/*
 *Program to demonstrate Zombie state of process.
 *Zombie state - Child process, once terminated, always waits to report status back to parent process. 
 *During this, if parent is busy with it's own task,or doesn't wait to collect the child's status,  this duration, till which the process status is not collected, that is Zombie state.
 */
#include<stdio.h>
#include<stdlib.h>
#include<sys/wait.h>
#include<unistd.h>

void main()
{
	printf("ZOMBIE DEMO\n");
	int x=fork();
	if(x  == 0)
	{
		exit(0);
	}
	else
	{
		sleep(30);
		wait(0);
	}
}
