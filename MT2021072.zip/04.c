/*
 *Open file , in read write mode, write content , and display it.
 */
#include<unistd.h>
#include<string.h>
#include<stdio.h>
#include<fcntl.h>
void main()
{
		int x=open("readfile.txt",O_RDWR|O_CREAT,0777);
		printf("Enter content to write to file\n");
		char buffer[100];
		scanf("%[^\n]s",buffer);
		int w=write(x,buffer,strlen(buffer));
		close(x);

		x=open("readfile.txt",O_RDWR,0777);
		printf("Content of file\n");
		read(x,&buffer,w);
		printf("%s",buffer);
}
