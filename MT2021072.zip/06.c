/*
 *Program to read content from standard input and writing back to standard output using read write system call
 * 0 - standard input file descriptor
 * 1 - standard output file descriptor
 */
#include<unistd.h>
#include<string.h>
#include<stdio.h>
#include<fcntl.h>
void main()
{
	printf("Enter the content to be read\n");
	char buffer[100];
	int x=read(0,&buffer,100);
	printf("Content \n");
	write(1,buffer,strlen(buffer));
}
