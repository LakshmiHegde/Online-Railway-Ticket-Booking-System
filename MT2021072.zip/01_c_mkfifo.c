/*
 *Creating named pipe, fifo file, using mkfifo system call.
 */
#include<sys/types.h>
#include<sys/stat.h>
#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
void main()
{
	int fd=mkfifo("myfifofile_mkfifo",0777);
	if(fd == 0)
		printf("FIFO file created successfully\n");
	else
		printf("Error");
}
