/*
 *Program to demonstrate, lseek system call, and view the result with octal dump
 */
#include<string.h>
#include<sys/types.h>
#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
#include<stdlib.h>
void main()
{
	int fd=open("file10.txt",O_TRUNC|O_RDWR|O_CREAT,0777);
	char buffer[100];
	if(fd == -1)
	{
		perror("");
		exit(0);
	}
	
	int w=write(fd,"First write",strlen("First write"));
	
	int l=lseek(fd,10,SEEK_CUR);
	
	printf("After moving 10 pointers ahead, currently file pointer at  %ld\n",(long)l);
	
	w=write(fd,"Second write",strlen("Second write"));
	
	printf("After writing %d bytes , currently file pointer at %ld\n",w,(long)lseek(fd,0,SEEK_CUR));

}

