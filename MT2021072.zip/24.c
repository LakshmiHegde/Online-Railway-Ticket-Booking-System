/*
 *Program to demonstrate Orphan process.
 *Process whose parent is alread terminated, is called orphan process.
 */
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
void main()
{
	int x=fork();
	if( x == 0)
	{
		sleep(10);
		printf("Child process\n");
	}
	else
	{
		printf("Parent process terminated\n");
		exit(0);
	}
}
