/*
 * Program to create, Hard link using system call link
*/
#include<unistd.h>
#include<stdio.h>
#include<fcntl.h>
void main()
{
	if(link("file.txt","../file_new.lnk") == 0)
		printf("Successful\n");
	else
	{
		perror("");
	}
}
