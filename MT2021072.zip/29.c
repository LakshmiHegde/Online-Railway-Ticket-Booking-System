/*
 *Program to get current scheduling policy of the program.
 *And modify it to some other policies
 
 */
#include<stdio.h>
#include<unistd.h>
#include<sched.h>
void main()
{
	printf("Current policy for process is ");
	struct sched_param prm;
	prm.sched_priority=10;
	switch(sched_getscheduler(getpid())) {
      		case SCHED_OTHER:
                         printf("SCHED_OTHER\n");
                         break;
      		case SCHED_FIFO:
                         printf("SCHED_FIFO\n");
                         break;
     	 	case SCHED_RR:
                         printf("SCHED_RR\n");
                         break;
      		default:
			 break;
	}
           
	sched_setscheduler(getpid(),SCHED_RR,&prm);
	printf("New policy for process is %d\n",sched_getscheduler(getpid()));
	
	sched_setscheduler(getpid(),SCHED_FIFO,&prm);
	printf("New policy for process is %d\n",sched_getscheduler(getpid()));
}
