/*
 *Program to find the type of given file. Input file name, is taken via cmd line arguments.
 *Use lstat or stat system call, which returns status and mode of file, that helps to extract the type of file.
 */
#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/stat.h>
void main(int argc,char* argv[])
{
	if(argc != 2)
	{
		printf("Provide file name as command line argument\n");
	}
	else
	{
		struct stat buf;
		int x=lstat(argv[1],&buf);
		if(x != -1)
		{
			switch(buf.st_mode & S_IFMT)
			{
				case S_IFBLK: printf("%s is Block device file\n",argv[1]);
						break;
				case S_IFCHR: printf("%s is Char device file\n",argv[1]);
						break;
				case S_IFDIR: printf("%s is Directory\n",argv[1]);
						break;
				case S_IFIFO: printf("%s is FIFO/PIPE\n",argv[1]);
						break;
				case S_IFLNK: printf("%s is Symbolic link\n",argv[1]);
						break;
				case S_IFREG: printf("%s is Regular file\n",argv[1]);
						break;
				case S_IFSOCK: printf("%s is Socket file\n",argv[1]);
						break;
				default: printf("Unknown\n");
			}
		}
		else
			perror("");
	}
}
