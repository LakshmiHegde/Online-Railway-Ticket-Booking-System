/*
 *Program to implement write lock, on record basis using fcntl system call.
 */
#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/types.h>
#include<sys/stat.h>
void main()
{
	struct 
	{
		int train_no;
		int tck_cnt;
	} db;


	printf("Select train number [1,2,3]\n");
	int n;
	scanf("%d",&n);

	
	struct flock f;
	f.l_type = F_WRLCK;
	f.l_start =(n-1)*sizeof(db);

	f.l_whence=SEEK_SET;
	f.l_len=sizeof(db);
	f.l_pid=getpid();
	
	int fd=open("inp2",O_RDWR);
	//move to the record you want to modify
	lseek(fd,(n-1)*sizeof(db),SEEK_SET);

	//lock
	fcntl(fd,F_SETLKW,&f);//set lock
	//read
	read(fd,&db,sizeof(db));
	printf("Current bookings %d\n",db.tck_cnt);

	//modify, increase ticket count by  1
	db.tck_cnt++;
	//write back to file, before  that move to start of the record you currently modifiedd. so that write takes from ther
	lseek(fd,-1*sizeof(db),SEEK_CUR);
	write(fd,&db,sizeof(db));
	printf("To book ticket, Press 1\n");
	getchar();
	getchar();
	
	f.l_type=F_UNLCK;
	fcntl(fd,F_SETLKW,&f);//set lock
	
	
	
	printf("Booked\n");
}
	
