/*
 *Program to create Demaon Process.
 */
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/stat.h>
void main()
{
	if(!fork())
	{
		setsid();
		chdir("/");
		umask(0);
		while(1)
		{
			printf("Hello, have a good day!\n");
			sleep(3);
		}
	}
	else
		exit(0);
}

