/*
 * Program to get minimum and maximum priority of scheduling policies.
 */
 
#include<stdio.h>
#include<unistd.h>
#include<sched.h>
void main()
{
	int max=sched_get_priority_max(SCHED_FIFO);
	int min=sched_get_priority_min(SCHED_FIFO);
	printf("Min max priority of FIFO scheduling policy, respectively are , %d , %d\n",min,max);
	max=sched_get_priority_max(SCHED_RR);
	min=sched_get_priority_min(SCHED_RR);
	printf("Min max priority of RR scheduling policy, respectively are , %d , %d\n",min,max);
}
