/*
 *Creating file using creat() system call, and displaying file descriptor
 */
#include<stdio.h>
#include<fcntl.h>
void main()
{
int stat=creat("text.c",S_IRWXU|S_IRGRP|S_IROTH);
if(stat == -1)
	printf("Creation failed\n");
else
	printf("File text.c created successfully , file descriptor %d\n",stat);
}
