/*
 *Program to get the priority of running program and modify it using nice system call
 */
#include<stdio.h>
#include<unistd.h>
#include<sys/stat.h>
#include<sys/resource.h>
void main()
{

	printf("Current priority %d\n",getpriority(PRIO_PROCESS,getpid()));
	
	int priority = 10;

	id_t  pid = getpid();
	
	nice(priority);
	printf("New priority %d\n",getpriority(PRIO_PROCESS,getpid()));

	nice(5);
	printf("New priority %d\n",getpriority(PRIO_PROCESS,getpid()));
}
