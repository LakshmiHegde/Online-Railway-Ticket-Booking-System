/*
 *Program to list all  environment variables of system
 */
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

extern char **environ;

void main()
{
	while(*environ != NULL)
	{
		printf("%s\n",*environ);
		*environ++;
	}
}
