/*
 *Program to implement write lock, on ticket reservation system.
 */
#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/types.h>

void main()
{
	struct flock f;
	f.l_type = F_WRLCK;
	f.l_whence = SEEK_SET;
	f.l_start=0;
	f.l_len=0;
	f.l_pid=getpid();
	
	int fd=open("inp",O_RDWR);
	int tck_no;
	read(fd,&tck_no,sizeof(tck_no));
	
	printf("Entry section\n");
	
	fcntl(fd,F_SETLKW,&f);//set lock
	
	printf("current ticket number %d\n",tck_no);
	
	tck_no++;
	printf("Updated ticket number %d\n",tck_no);
	lseek(fd,0,SEEK_SET);
	
	write(fd,&tck_no,sizeof(tck_no));
	
	printf("Inside critical section\nPress 0 to exit\n");
	getchar();
	
	printf("Unlocked\n");
	
	f.l_type=F_UNLCK;
	fcntl(fd,F_SETLK,&f);
	close(fd);
	
	printf("Exit section\n");
}
	
