/*
 *Program to display, details about file, which includes, inode numbers, size, number of blocks, time of creation etc.
 *Use the stat system call, which returns result in buffer pointed by stat structure variable.
 */
#include<stdio.h>
#include<fcntl.h>
#include<sys/time.h>
#include<unistd.h>
#include<time.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<stdlib.h>
#include <sys/types.h>
#include <sys/sysmacros.h>

void main()
{
	char buffer[100],fname[30];
	printf("enter filename\n");
	scanf("%s",fname);
	struct stat res;
	int x=stat(fname,&res);
	
	if(x==0)
	{
		printf("Inode number %ld\n",(long)res.st_ino);
		printf("Number of hard links %ld\n",(long)res.st_nlink);
		printf("User ID %ld\n",(long)res.st_uid);
		printf("Group ID %ld\n",(long)res.st_gid);
		printf("Size %lld bytes\n",(long long)res.st_size);
		printf("Block size for file system %ld bytes\n",(long)res.st_blksize);
		printf("Number of blocks %lld\n",(long long)res.st_blocks);
                printf("Mode:  %lo (octal)\n",(unsigned long) res.st_mode);
		struct tm *dt;
		printf("Last status change:       %s", ctime(&res.st_ctime));
           printf("Last file access:         %s", ctime(&res.st_atime));
           printf("Last file modification:   %s", ctime(&res.st_mtime));

	}
	else
		perror("");
}
