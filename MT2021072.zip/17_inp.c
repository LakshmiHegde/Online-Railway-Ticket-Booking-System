/*
 *Program to store ticket number as input in a file, which is used while booking.
 */
#include<stdio.h>
#include<fcntl.h>
#include<sys/types.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/stat.h>
void main()
{

	int fd = open("inp",O_RDWR|O_CREAT,0777);
	int tck=10;
       	
	int wr=write(fd,&tck,sizeof(tck));
	
	close(fd);
    	
	int x;
	fd=open("inp",O_RDONLY);
	int r=read(fd,&x,sizeof(int));
	
	printf("Value= %d\n",x);
	close(fd);
}

