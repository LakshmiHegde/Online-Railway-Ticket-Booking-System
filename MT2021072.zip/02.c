/*
 * Program to run infinite loop. 
*/

#include<stdio.h>
void main()
{
	for(;;)
	{
	}
}
