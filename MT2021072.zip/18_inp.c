/*
 *Program to create 3 train records , and store it in a file.
 */
#include<stdio.h>
#include<fcntl.h>
#include<sys/types.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/stat.h>
void main()
{
	struct 
	{
		int train_no;
		int tck_no;
	} db[3];

	for(int i=0;i<3;i++)
	{
		db[i].train_no=i+1;
		db[i].tck_no=0;
	}
	int fd = open("inp2",O_RDWR|O_CREAT,0777);
	
	int wr=write(fd,&db,sizeof(db));
	
	close(fd);
    	
	
}

