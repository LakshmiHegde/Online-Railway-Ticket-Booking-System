/*
 *Program to output mode of file,i,e opened.
 *You can use fcntl, which has F_GETFL cmd, that helps in getting file status flags and also access mode of file, mask it with O_ACCMODE, to get only the access mode.
 */
#include<fcntl.h>
#include<stdio.h>
void main()
{
	char fname[30];
	printf("enter file name : ");
	scanf("%s",fname);
	int fd=open(fname,O_RDONLY);
	
	int mode=fcntl(fd,F_GETFL);
	mode=mode & O_ACCMODE;

	if(mode == 0)
		printf("Opened in Read Only Mode\n");
	else if(mode == 1)
		printf("Opened in Write Only Mode\n");
	else if(mode == 2)
		printf("Opened in Read Write mode\n");
}
