/*
 *Program to duplicate file descriptor, and append the file, with both original and copied descriptor ,using dup2() system call

 *Using dup2 you can even specify, copied file descriptor value, as per your interest.
 */
#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<string.h>
#include<unistd.h>
void main()
{
	char fname[30];
	printf("enter file name\n");
	scanf("%s",fname);
	int x=open(fname,O_RDWR);
	
	int copy=dup2(x,100);//creating duplicate for 3 fd, now copy should store 5 , which is currently least unused
	printf("Old descriptor = %d\nCopied desc=%d\n",x,copy);

	write(x,"This is using original descriptor\n",strlen("This is using original descriptor\n"));
	write(copy,"This is using copied descriptor\n",strlen("This is using copied descriptor\n"));

}


