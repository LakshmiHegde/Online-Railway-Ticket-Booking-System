/*
 *Program to demonstrate use of EXCL flag .
 *Mainly used with CREAT flag
 *Which helps in avoiding overwrite to file, if file already exists.
 */
#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
void main()
{
	int fd=open("newfile",O_CREAT|O_EXCL|O_RDWR,0777);
	if(fd > 0)
		printf("File opened for read write mode succesfully , file descriptor = %d\n",fd);
	else
		printf("File already exists\n");
}
