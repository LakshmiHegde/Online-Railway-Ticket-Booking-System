/*
 *
 *Program to duplicate file descriptor, and append the file, with both original and copied descriptor ,using fcntl() system call
 *fcntl , enables you to execute operation on the file descriptor passed. You can specify F_DUPFD , as operation, which duplicates file descriptor
 */
#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<string.h>
#include<unistd.h>
void main()
{
	char fname[30];
	printf("enter file name\n");
	scanf("%s",fname);
	int x=open(fname,O_RDWR);
	
	
	int copy=fcntl(x,F_DUPFD);//creating duplicate for 3 fd, now copy should store 5 , which is currently least unused
	printf("Old descriptor = %d\nCopied desc=%d\n",x,copy);

	write(x,"This is using original descriptor\n",strlen("This is using original descriptor\n"));
	write(copy,"This is using copied descriptor\n",strlen("This is using copied descriptor\n"));

}


