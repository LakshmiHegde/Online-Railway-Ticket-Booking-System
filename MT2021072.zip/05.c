/*
 *Program to create 5 files on run, and view the file descriptor table, in proc directory, associated with this process. (/proc/pid/fd)
 *
 */
#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
void main()
{
	int counter=0;
	char path[50];
	for(;;)
	{
		if(counter<5)
		{
			sprintf(path,"/home/lakshmihegde/Desktop/file%d",counter);
			int fd=creat(path,0644);
			if(fd == -1)
				printf("Creation failed\n");
			else
				printf("File descriptor %d\n",fd);
			counter++;
		}
		if(counter == 5)
			counter=5;

	}
}
