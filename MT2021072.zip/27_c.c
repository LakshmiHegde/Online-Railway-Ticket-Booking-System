/*
 *3. execle - Same as execl, except that, you can even provide the environment details, for the program that is passed in execle.
 */
#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
void main()
{
	char *env[] = { "HOME=/usr/home", "LOGNAME=home",NULL};
	int status=execle("/bin/ls","ls","-Rl",NULL,env);
	if(status == -1)
		perror("");
}
