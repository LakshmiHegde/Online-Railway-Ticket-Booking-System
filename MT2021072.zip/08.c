/*
 *program to open a file in read only mode, read line by line and display each line as it is read
 */
#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include<unistd.h>
#include<fcntl.h>
void main(int argc, char *argv[])
{
	if(argc <2)
	{
		printf("Provide file as command line argument\n");
		exit(0);
	}
	int fd1=open(argv[1],O_RDONLY);
	char ch;
	char line[10];
	int index=0;
	while(read(fd1,&ch,1) != 0)
	{
		if(ch!='\n' && index < 10)
			line[index++]=ch;
		else
		{
			if(index<10)
			{
			      	line[index++]=ch;
				printf("%s",line);
			}
			else
			{
				 printf("%s%c",line,ch);
			}
			 memset(line,0,10);
			 index=0;
		}
	
	}
}
