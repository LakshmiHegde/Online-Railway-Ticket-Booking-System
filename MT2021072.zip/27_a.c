/*
 *Program to demonstrate exec family of system calls.
 *1. execl - You should pass the absolute path of executable file inside, and also if any arguments,to be given, for executable program , pass it one by one, and end with null.
 */
#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
void main()
{
	int status=execl("/bin/ls","ls","-Rl",NULL);
	if(status == -1)
		perror("");
}
